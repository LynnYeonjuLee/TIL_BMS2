from django import forms

from .models import Board, Comment


class BoardForm(forms.ModelForm):
    class Meta:
        model = Board
        fields = '__all__'


class CommentForm(forms.ModelForm):
    class Meta:
        model = Comment
        # fields = ['content', ]
        exclude = ['board',]
