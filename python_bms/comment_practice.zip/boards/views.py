from django.shortcuts import render, redirect, get_object_or_404
from django.views.decorators.http import require_POST

from .models import Board, Comment
from .forms import BoardForm, CommentForm


def index(request):
    boards = Board.objects.all()
    context = {
        'boards': boards,
    }
    return render(request, 'boards/index.html', context)


def new(request):
    if request.method == "POST":
        form = BoardForm(request.POST)
        if form.is_valid():
            board = form.save()
            return redirect('boards:detail', board.pk)
    else:
        form = BoardForm()
    
    context = {
        'form': form,
    }

    return render(request, 'boards/form.html', context)


def detail(request, pk):
    board = get_object_or_404(Board, pk=pk)
    context = {
        'board': board,
    }
    return render(request, 'boards/detail.html', context)


def update(request, pk):
    board = get_object_or_404(Board, pk=pk)
    if request.method == "POST":
        form = BoardForm(request.POST, instance=board)
        if form.is_valid():
            form.save()
            return redirect('boards:detail', board.pk)
    else: 
        form = BoardForm(instance=board)
    
    context = {
        'form': form,
    }
    return render(request, 'boards/form.html', context)


def delete(request, pk):
    board = get_object_or_404(Board, pk=pk)
    if request.method == "POST":
        board.delete()
        return redirect('boards:index')
    return redirect('boards:detail', pk)
