T = int(input())
table = [[0]*100 for _ in range(100)]
for tc in range(1, T+1):
    l, b = map(int, input().split())
