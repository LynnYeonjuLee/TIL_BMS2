x, y = map(int(input().split()))
arr = [[]]