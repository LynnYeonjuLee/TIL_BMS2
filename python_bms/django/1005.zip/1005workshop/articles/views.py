from django.shortcuts import render, get_object_or_404
from .models import Article
from .serializers import (
    ArticleListSerializer, 
    ArticleSerializer
)
# 긴 이름을 불러올 때 이렇게 쓰기도 한다. 
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view
# Create your views here.
@api_view(['GET', 'POST'])
def article_list(request):
    '''
    GET /api/v1/articles
    POST /api/v1/articles
    '''
    # 만약 method가 GET이라면...
    if request.method == 'GET':
        # 1. 데이터베이스에 있는 모든 게시글을 가져온다.
        articles = Article.objects.all()
        # 2. 전송 가능한 형태(JSON)으로 바꿔준다.
        serializer = ArticleListSerializer(articles, many=True)
        # 3. 마지막으로 Response 함수를 이용하여 반환
        return Response(data=serializer.data)
        
    elif request.method == "POST":
        # 1. JSON => 파이썬 데이터 타입으로 변환
        serializer = ArticleListSerializer(data=request.data)
        # 2. 유효성 검사
        if serializer.is_valid(raise_exception=True):
            # 3. 저장
            serializer.save()
            return Response(data=serializer.data, status=status/HTTP_201_CREATED)

@api_view(['GET', 'PUT', 'DELETE'])
# require_HTTP_methods(['GET']) 는 달리 특정 메소드를 받는다?
def article_detail(request, article_pk):

    article = get_object_or_404(Article, pk=article_pk)

    if request.method == 'GET':
        
        serializer = ArticleSerializer(article) # JSON
        return Response(serializer.data)
    
    elif request.method == 'POST':
        serializer = ArticleSerializer(instance=article ,data=request.data)
        if serializer.is_valid():
            serializer.save()
            return Response(serializer.data)

    elif request.method == 'DELETE':
        article.delete()
        data = {
            'article_pk':article_pk
        }
        return Response(data, status=status.HTTP_204_NO_CONTENT)