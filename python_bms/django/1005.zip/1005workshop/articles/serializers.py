from rest_framework import serializers
from .models import Article
class ArticleListSerializer(serializers.ModelSerializer):
    '''
    시리얼라이저를 사용하는 이유 2가지

    1. 데이터베이스에서 가져온 쿼리셋을 JSON으로 바꿔서 응답해주기 위해(GET)
    2. 요청으로 받아온 JSON 형태의 데이터를 반대로 파이썬 객체로 만들어서 저장하기 위해(POST)
    '''
    class Meta:
        model = Article
        fields = ('id', 'title')


class ArticleSerializer(serializers.ModelSerializer):
    class Meta:
        model = Article
        fields = ('id', 'title', 'content', 'created_at', 'updated_at')