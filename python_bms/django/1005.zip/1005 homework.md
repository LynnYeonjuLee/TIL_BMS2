# 1005 homework

## 1. 

T

F

T

T

```
POST/worldcup/teams/18585/
```



## 2. 

## 3. 

```python
class StudentSerializer(serializers.ModelSerializer):

    class Meta:
        model = Student
        fields = ('id', 'name', 'age', 'address')
```



## 4. 

